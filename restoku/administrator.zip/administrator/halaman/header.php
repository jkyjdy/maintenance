<div class="logo"  >
            <table border="0" style="width:100%">
                <tr>
                    <td style="width:85%"><h1>Restoku</h1></td>
                    <td>
                        Welcome,<br>
                        <b>Nama Anda</b><hr>
                        <a href="../login/logout.php">>> Keluar</a>
                    </td>
                </tr>
            </table>
            
        </div>