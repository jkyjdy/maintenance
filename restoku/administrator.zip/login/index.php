<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List menu pesanan</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="honeydew">
    <div class="container">
        <form action="login.php" name="form2" method="post">
        <div class="row">
            <h1>Form Pemesanan Makanan dan Minuman</h1>
            <hr>
        </div>
        <div class="row">
            <div class="table-makanan">
                <a href="https://programmerindo.com/portfolio/toserdas-myapps/">
                    <img src="https://programmerindo.com/wp-content/uploads/2022/01/mockup-komp-tablet-laptop-1536x1097.png" style="width:100%">
                </a>
            </div>
            <div class="table-pesanan">
                <b>Login Pagi</b><hr>
                
                    Username :<br>
                    <input type="text" name="username" id=""><br><br>
                    Password<br>
                    <input type="password" name="password" id="">
                    <hr>
                    <input type="submit" value="Login" />
            </div>
        </div>
        </form>
        
    </div>
</body>
</html>