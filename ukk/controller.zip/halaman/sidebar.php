    <br>
        <b>NAVIGASI</b>
        <hr>
        <a href="index.php">
            <div class="menu">
                Dashboard
            </div>
        </a>
        <a href="produk.php">
            <div class="menu">
                Produk
            </div>
        </a>
        <a href="penjuaan.php">
            <div class="menu">
                Penjualan
            </div>
        </a>
        <a href="pelanggan.php">
            <div class="menu">
                Pelanggan
            </div>
        </a>